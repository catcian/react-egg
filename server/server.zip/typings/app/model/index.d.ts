// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportComment = require('../../../app/model/comment');
import ExportHouse = require('../../../app/model/house');
import ExportImgs = require('../../../app/model/imgs');
import ExportOrder = require('../../../app/model/order');
import ExportRoles = require('../../../app/model/roles');
import ExportUser = require('../../../app/model/user');
import ExportUserDetail = require('../../../app/model/userDetail');
import ExportUserRoles = require('../../../app/model/userRoles');

declare module 'egg' {
  interface IModel {
    Comment: ReturnType<typeof ExportComment>;
    House: ReturnType<typeof ExportHouse>;
    Imgs: ReturnType<typeof ExportImgs>;
    Order: ReturnType<typeof ExportOrder>;
    Roles: ReturnType<typeof ExportRoles>;
    User: ReturnType<typeof ExportUser>;
    UserDetail: ReturnType<typeof ExportUserDetail>;
    UserRoles: ReturnType<typeof ExportUserRoles>;
  }
}
