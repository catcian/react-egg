'use strict';

module.exports = {
  // property
  set token(params) {
    this.set('token', params);
  },
};
